extjs4-mvc-json-crud-php-mysql
==============================

ExtJS 4 MVC Example - CRUD Grid with JSON, Ajax, PHP and MySQL